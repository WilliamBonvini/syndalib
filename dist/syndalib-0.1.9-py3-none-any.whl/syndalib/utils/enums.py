COLORS = ["forestgreen",
          "lightseagreen",
          "dodgerblue",
          "navy",
          "crimson",
          "darkorange"]

OUTLIERS_COLOR = "slategray"
