COLORS = ["forestgreen",
          "darkorange",
          "lightseagreen",
          "dodgerblue",
          "navy",
          "crimson"]

OUTLIERS_COLOR = "slategray"
